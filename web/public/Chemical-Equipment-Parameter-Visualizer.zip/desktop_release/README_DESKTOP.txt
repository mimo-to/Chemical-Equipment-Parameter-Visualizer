Chemical Equipment Visualizer


Welcome! 

This is the desktop client for the Chemical Equipment Parameter Visualizer.

HOW TO RUN:

1. Ensure your Backend Server is running (http://127.0.0.1:8000).
2. Double-click "Chemical_Equipment_Visualizer_Desktop.exe" to launch.
3. Login with your credentials.

TROUBLESHOOTING:

If the app doesn't open or says "Connection Failed":
- Check if the backend is running.
- Check "desktop_app.log" in this folder for details.
